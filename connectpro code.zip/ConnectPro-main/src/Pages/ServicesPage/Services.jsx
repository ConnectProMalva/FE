import React from 'react'
import Header from '../../components/Header/Header'
import ServiceHero from './ServiceHero'
import HouseHold from './HouseHold'
import Plumbing from './Plumbing'
import Errands from './Errands'
import Banner from '../../Banner/Banner'
import Footer from '../../components/Footer/Footer'
import Loader from '../../utils/Loader'

const Services = () => {
  return (
    <>

    <Loader />
    <Header/>
    <ServiceHero/>
    <HouseHold/>
    <Plumbing/>
    <Errands/>
    <Banner/>
    <Footer/> 
    </>
  
  )
}

export default Services