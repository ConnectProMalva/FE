import React from 'react'
import ServiceCard from '../../components/ReUsable/ServiceCard';

const Errands = () => {
    const texts = [
        "Grocery shopping",
        "Package delivery",
        "Personal chauffeur services",
        "Prescription pick-ups"
        
      ];
  return (
    <div>
        <ServiceCard
         image="https://res.cloudinary.com/drphumgcb/image/upload/v1720743271/Rectangle_12_2_mcoead.png"
         title="Driving and Errands"
         description="Need a driver or someone to run errands? We’ve got you covered"
         texts={texts}
        />
      
    </div>
  )
}

export default Errands