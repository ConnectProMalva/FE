import React from "react";


const ServiceHero = () => {
  return (
    <main className="heroCon pt-[6rem] md:pt-[10rem] bg-serviceHero">
      <section className="flex flex-col lg:flex-row justify-between px-4 md:px-[2rem] lg:px-[4rem] items-center">
        <figcaption className="heroText mb-8 text-center lg:text-left w-full md:w-[50%]">
          <h1 className="text-3xl lg:text-[4rem] leading-[2.5rem] lg:leading-[4.3rem] font-semibold mb-4">
          Whatever you need, 
          <br className="hidden lg:block" />we’re up for the  <br className="hidden lg:block" /> task!
          </h1>
          <p className="text-base md:text-xl w-full lg:w-[80%]">
          ConnectPro offers a wide range of services to help you with everyday tasks and specialized jobs. Whether you need assistance with household chores, repairs, or errands, our trusted professionals are here to help.
          </p>
        </figcaption>
        <figure className="heroimg hidden md:block overflow-hidden">
          <img
            className="w-full h-[450px] rounded-lg  border-gray-300  transform transition duration-500
     hover:scale-105 "
            src="https://res.cloudinary.com/drphumgcb/image/upload/v1720739065/Rectangle_11_xar9tc.png"
            alt="Hero"
          />
        </figure>
        <figure className="heroimg overflow-hidden md:hidden block w-full md:w-[50%] mt-8 md:mt-0">
          <img
            className="w-full h-auto md:h-[450px] rounded-lg border-gray-300 transform transition duration-500 hover:scale-105"
            src="https://res.cloudinary.com/dytlpvw1o/image/upload/v1720100898/Rectangle_11_ewdcmh.png"
            alt="Hero"
          />
        </figure>
      </section>
    </main>
  );
};

export default ServiceHero;



