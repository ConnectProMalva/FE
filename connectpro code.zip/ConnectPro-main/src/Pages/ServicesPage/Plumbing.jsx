import React from 'react'
import ServiceCard from '../../components/ReUsable/ServiceCard'

const Plumbing = () => {
    const texts = [
        "Faucet and sink repairs",
        "Pipe installation and repair",
        "Toilet repairs and installations",
        "Drain cleaning",
      ];
  return (
    <>
      <section className="c pt-[4rem]">
        <ServiceCard
         imageOnRight={true}
         image="https://res.cloudinary.com/drphumgcb/image/upload/v1720742814/Rectangle_12_1_vrw6j5.png"
         title="Plumbing Services"
         description="Get professional plumbing services for all your needs."
         texts={texts}/>
        
      </section>
    
    </>
  )
}

export default Plumbing

