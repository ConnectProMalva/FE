import React from 'react'
import ServiceCard from '../../components/ReUsable/ServiceCard';

const HouseHold = () => {
    const texts = [
        "Cleaning and tidying",
        "Laundry and ironing",
        "Dishwashing",
        "Dry-cleaning",
        "Organizing clothes"
      ];
  return (
    <div>
        <ServiceCard
    // imageOnRight={true}
      subtitle="For Artisian"
      image="https://res.cloudinary.com/drphumgcb/image/upload/v1720742038/Rectangle_12_i6g1rs.png"
      title="HouseHold Chores"
      description="Keep your home clean and organized with our reliable household chore services."
      texts={texts}/>
      
    </div>
  )
}

export default HouseHold