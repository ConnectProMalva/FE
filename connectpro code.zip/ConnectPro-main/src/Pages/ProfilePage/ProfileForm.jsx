import { Link } from "react-router-dom";

const ProfileForm = () => {
    return (
      <form className='max-w-sm mt-5 mx-auto'>
        <div className='flex mb-10'>
            <div className="mb-4">
                <img src="https://res.cloudinary.com/drphumgcb/image/upload/v1720729466/Connect%20pro/ue7huosnwimnvjiz2mj6.png" id="uploaded-photo"  alt="Uploaded Photo" className="w-full h-auto border rounded-lg"/>
            </div>
            <div>
                <label htmlFor="file-upload" className="cursor-pointer">
                    <span className="py-3 px-5 border font-bold shadow-md">Upload photo</span>
                    <p className="mt-3">JPG, PNG, or GIF. Max size of 1MB</p>
                </label>
                <input id="file-upload" name="photo" type="file" className="hidden"/>
            </div>
        
        </div>
        <div className='mb-2'>
          <label htmlFor='text' className='font-bold block mb-2'>Full Name</label>
          <input
            type='text'
            id='text'
            placeholder='e.g John Doe'
            className='font-normal w-full border border-borderColor outline-password rounded-md shadow-sm bg-white text-neutral py-[11px] px-[11px]'
            autoComplete='off'
          />
        </div>
        <div className='mb-4'>
          <label htmlFor='suburb' className='font-bold block mb-2'>Suburb</label>
          <input
            type='text'
            id='suburb'
            placeholder='Choose a Suburb'
            className='font-normal w-full border border-borderColor outline-password rounded-md shadow-sm text-neutral py-[11px] px-[11px]'
            autoComplete='off'
          />
        </div>
        <div className='mb-4'>
          <label htmlFor='phone' className='font-bold block mb-2'>Phone number</label>
          <div className="flex items-center border rounded p-2 outline-password">
                <select id="country-code" name="country-code" className="mr-2 w-[50px]">
                    <option value="NG"> +123</option>
                    <option value="CA">+1 </option>
                    <option value="GB">+44</option>
          
                </select>
                <input
                type='tel'
                id='phone'
                placeholder='80 8345 6789'
                className='font-normal w-full border border-borderColor outline-password rounded-md shadow-sm text-neutral py-[11px] px-[11px]'
                autoComplete='off'
                />
            
            </div>
         
        </div>
        <div className="mt-5">
        <button
          type='submit'
          className='bg-buttonBackground border border-borderColor hover:bg-white w-full text-buttonColor shadow-sm font-bold py-2 px-4 rounded'
        >
          Complete profile
        </button>
    </div>
        
      </form>
    );
  }
  
  export default ProfileForm;
  