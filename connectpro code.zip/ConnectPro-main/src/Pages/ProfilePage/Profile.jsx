import React, { useState, useEffect } from 'react'
import Modal from '../../components/Modal';
import LandingPage from '../LandingPage/LandingPage';
import ProfileForm from './ProfileForm';

const Profile = () => {
    const [isModalOpen, setIsModalOpen] = useState(false);

  const closeModal = () => {
    setIsModalOpen(false);
  };

  useEffect(() => {
    // Open the modal when the component mounts
    setIsModalOpen(true);
  }, []);
  return (
    <div className="profile-page">
        <LandingPage />
        <Modal
            isOpen={isModalOpen}
            closeModal={closeModal}
            title="Complete Your Profile"
            paragraph="This makes you more visible to clients">
        <div className="">
         <ProfileForm/>
        </div>
        </Modal>
    </div>
  )
}

export default Profile