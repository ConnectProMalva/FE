import React from 'react'


const ClientPortfolio = () => {
    
      
   
  return (
    <>
    
      
                <div className='text-center'>
                    <h3 className='font-bold text-2xl'>Portfolio is empty</h3>
                    <p>Showcase your expertise through your works.</p>
                    <button className='bg-password rounded text-white py-3 px-10 mt-5'>Add work experience</button>
                </div>

        
    </>
 
  )
}

export default ClientPortfolio