import React, { useState, useEffect } from 'react';
import Modal from '../../components/Modal';
import SignUpForm from './SignUpForm';
import LandingPage from '../LandingPage/LandingPage';

const SignUp = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const closeModal = () => {
    setIsModalOpen(false);
  };

  useEffect(() => {
    // Open the modal when the component mounts
    setIsModalOpen(true);
  }, []);

  return (
    <div className="signup-page">
     <LandingPage />

      <Modal
        isOpen={isModalOpen}
        closeModal={closeModal}
        title="Get started with ConnectPro"
        paragraph="Create an account and access 10,000+ jobs"
      >
        <div className="">
          <SignUpForm />
        </div>
      </Modal>
    </div>
  );
};

export default SignUp;
