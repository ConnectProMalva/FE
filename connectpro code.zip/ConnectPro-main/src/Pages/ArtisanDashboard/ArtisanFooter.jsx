import React from 'react'

const ArtisanFooter = () => {
  return (
    <section className='footer  mt-[4rem] relative border flex justify-center items-center text-center px-4 p-4 md:px-[5rem] '>
        <p className=''>&copy;2024 ConnectPro. All rights reserved</p>
    </section>

  )
}

export default ArtisanFooter